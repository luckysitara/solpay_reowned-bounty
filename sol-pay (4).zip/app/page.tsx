"use client"

import Header from "../src/components/Header"

export default function SyntheticV0PageForDeployment() {
  return <Header />
}